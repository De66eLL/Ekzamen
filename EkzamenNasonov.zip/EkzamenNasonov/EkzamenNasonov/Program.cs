﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EkzamenNasonov
{
    class Program
    {
        
        static void Main()
        {

            int k = 0, sum = 0;
            Console.WriteLine("Введите числа");
            do
            {
                int a = Convert.ToInt32(Console.ReadLine());
                sum = sum + a;
                k++;
            }
            while (sum < 100);
            Console.WriteLine("Итоговая сумма равна:");
            Console.WriteLine(sum);
            Console.WriteLine("Колличество операций было сделано:");
            Console.WriteLine(k);
            Console.ReadLine();
        }
    }

}

